---
name: schrijfkracht-app-bouwen
description: Invoke when the user wants to generate, complete, test, or revise the full Schrijfkracht static learning application from the supplied master specification.
allowed-tools: code-execution
compatibility: 'Requires data: Schrijfkracht master specification. Requires env: python, filesystem. Authored-on: Bizchat'
---

## Purpose
Build or revise the complete Schrijfkracht application as one coherent, testable static website. Invoke this skill when the requested work concerns implementation, validation, packaging, or documentation of Schrijfkracht.

## Uses
- Agent capabilities: code interpreter
- Input data: the user's Schrijfkracht master specification

## Instructions
1. **Establish the build contract.** Treat the latest user-supplied master specification as the source of truth. Extract every required route, level, product, language level, data file, rule, accessibility constraint, privacy rule, test, and acceptance criterion into an internal checklist. Preserve Dutch interface copy exactly where the specification requires it.
2. **Create the project structure.** Generate every required file and folder, plus only clearly justified additions. Use HTML5, CSS3, vanilla JavaScript, ES modules, local JSON, and local SVG. Keep all paths relative and GitHub Pages subpath-safe. Do not introduce frameworks, CDNs, external fonts, analytics, databases, or required package installation.
3. **Implement state and privacy first.** Keep student text and progress only in browser memory. Allow localStorage only for non-text preferences. Add unsaved-work warnings, explicit clearing, safe route changes, and no persistence of student text in service-worker caches or browser databases.
4. **Implement the interface and navigation.** Build the responsive block-world visual system, start flow, product and 1F/2F choice, keyboard navigation, reduced-motion mode, visible focus, semantic structure, accessible dialogs, ARIA live regions, and minimum touch targets. Keep the writing task visually primary.
5. **Build the complete content bank.** Cover all four products at both 1F and 2F. For each of the eight routes include the required example, at least five viewing questions, alternate control questions, puzzle, two guided tasks, and two independent tasks. Store editable content in separate JSON files and keep all scenarios fictional.
6. **Implement Level 1.** Provide example study, closed-question practice with disappearing answer bubbles, accessible puzzle controls, guided writing, concrete self-checks, reading card, reflection, and strict completion gates. Do not provide spelling or grammar correction in this level.
7. **Implement the reusable quiz behavior.** Randomize at least three answers. After one unsuitable choice, remove that choice while retaining its empty place, show one hint, and move focus logically. After a second unsuitable choice, clear choices, explain with an independent example, and offer a comparable control question. Allow supported completion after discussion without scores or punishment.
8. **Implement the feedback architecture and rule engine.** Create the rule provider, disabled AI provider, merge step, safety filter, display module, and notification-progress handling. Use the required input/output shapes, recalculate positions from current text, deduplicate notifications, and store handled notifications in memory. Implement R01-R28 with conservative confidence handling, tests, exceptions, and the separate signal-word library.
9. **Implement Level 2.** Support a browser-memory snapshot, one notification at a time in the required category order, three help levels, re-analysis of current text, discussed-versus-corrected status, nonblocking tips, and the mandatory collaboration screen. Gate progression on language checking, required handling, collaboration, and reflection.
10. **Implement Level 3.** Provide a new independent task for the same product and level, without examples, automated language feedback, or content hints. Disable browser spelling/autocorrect where possible and document that browsers may ignore this. Include only the permitted neutral word count.
11. **Implement export and completion.** Build the teacher-message preview, clipboard copy, UTF-8 text download, mailto fallback, optional research export, teacher assessment form, completion screen, and confirmation before clearing work. Never send mail directly and never turn activity counts into grades.
12. **Implement offline and AI readiness.** Use the exact configuration defaults, keep AI off with no external requests, add the future prompt and AI documentation, and validate future AI output conservatively. Add a versioned service worker that caches application assets only and removes old caches.
13. **Create the test environment.** Implement tests.html with visible results for language rules, quiz states, all routes and levels, progression gates, collaboration, exports, disabled/time-out AI behavior, offline/cache behavior, subpath operation, privacy settings, accessibility, reduced motion, focus, and 360-pixel layout. Include at least three positive and two negative test sentences per rule plus contextual exceptions.
14. **Document and verify.** Write the README and all required Dutch documentation. Run only tests that can actually be executed in the current environment; report those results truthfully. Distinguish automated checks from manual teacher checks. Record independently made design decisions.
15. **Package the result.** Return one downloadable ZIP containing the complete site. Before completion, compare the project against every acceptance criterion, verify that all eight routes are present, and ensure no placeholder, partial demo, omitted product, or unsupported claim remains.

If a requested requirement conflicts with privacy, accessibility, safety, or didactic reliability, choose the safer implementation and document the decision. If an environment limitation prevents a test, complete the implementation and list the exact manual verification still needed.

## Parameters
- `specification`: latest full Schrijfkracht requirements supplied by the user
- `revision_request`: optional targeted change to an existing generated project
- `existing_project`: optional current project files for revision

## Output
- A downloadable ZIP of the complete static website with all required source, data, assets, AI preparation, tests, and documentation
- A concise build summary
- A truthful test report separating executed checks from manual checks
- A list of documented design decisions and any remaining environment-specific verification